﻿using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Networking.Types;
using UnityEngine.Networking.Match;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class NetClient : NetBase {

    public NetworkClient Client = new NetworkClient();
    public int Port = 1337;
    public string IP = "127.0.0.1";
   
    public string Name = "Bob??";

    public string ErrorStr = "";
    public bool checkErr( ref string msg ) {
        if(ErrorStr != "") {
            msg = ErrorStr;
            return true;
        } else
            return false;
    }

    public int MyId = -1;

    class Peer {
        //public NetworkConnection Con;
        public Peer( string name, short team ) {
            Name = name;
        }
        public string Name;
        //  public Team Team;
        //public int TeamMask;
    };
    Dictionary<int, Peer> Peers = new Dictionary<int, Peer>();


    void send<T>(T msg) where T : Msg, IMsg {  send( msg, Client.connection); }
    void sendUR<T>(T msg) where T : Msg, IMsg { sendUR(msg, Client.connection); }

    T recvMsg<T>(NetworkMessage msg) where T : Msg, new() {
        T m = msg.ReadMessage<T>();
      //  Debug.Log("NetClient::recvMsg " + typeof(T));
        return m;
    }
    void reg_Sub<T>( System.Action<T, NetworkConnection> recv) where T : Msg, IMsg, new() { Client.RegisterHandler((new T()).getId(), (NetworkMessage msg) => { recv(recvMsg<T>(msg), msg.conn); }); }


    new void recv(Msg_Ping p, NetworkConnection from) {
      //  Debug.Log("Ping ");
        send(new Msg_Ping());
    }
  /*  void recv(Msg_UnitList p, NetworkConnection from) {
        Debug.Log("Msg_UnitList.. ");

        if(Units.Count != 0) {
            foreach(Unit u in Units.Values)
                if( u != null) Destroy(u.gameObject);
            Units.Clear();
        }

        Debug.Log(" pre count " + FindObjectsOfType<Unit>().Length);

        foreach(var ud in p.Units) {
            var u = Unit.spawn(cell(ud.CellI), cell(ud.DCellI), ud.Number, ud.Team);
            Units.Add(u.Id = ud.Id, u);
            Debug.Log(" unit " + u.Id + "  at " + ud.CellI + "  team " + ud.Team + "  number " + ud.Number);
        }

    }

    void recv(Msg_SetUnitDest msg, NetworkConnection from) {
        Debug.Log("Msg_SetUnitDest c  " + msg.To);
        Unit u = unit(msg.UnitID); if(u == null) return;
        Cell c = cell(msg.To); if(c == null) return;
        setMyDestCell_Final(u, c);
    }

    void recv(Msg_DragCB msg, NetworkConnection from) {
        Unit u = unit(msg.UnitID); if(u == null) return;
        dragCB_Final(u, msg.To);
    }*/
   // void recv(Msg_SetReady msg, NetworkConnection from) { Systm.setReady(msg.ReadyMask, -1); }
 /*   void recv(Msg_Proc msg, NetworkConnection from) {
        Systm.Processing = msg.Start;
        Systm.setReady(msg.Start ? -1: 0, -1); 
    }*/



    void onConnect( NetworkMessage msg ) {

        int id = msg.conn.connectionId;
        Debug.Log("connecting?? " + id);
       // Message = "connecting?? "+msg.ToString();

        send(new Msg_Handshake( Name ));

    }
    void onDisconnect( NetworkMessage msg ) {
        Debug.Log("disconnected?? ");
    }

    void recv( Msg_Generic msg, NetworkConnection from ) {
        Debug.Log("Msg_Generic  " + msg.SM.ToString());
        switch(msg.SM) {
            case Msg_Generic.SubMessage.ClientMismatch:
                //(fuck)
                ErrorStr = "Client mismatch..";
                Client.Disconnect();
                return;
            case Msg_Generic.SubMessage.RejectInvalidName:
                ErrorStr = "Name taken or invalid";
                return;
        }
        Debug.LogError("unhandled");
    }
    void recv( Msg_Welcome msg, NetworkConnection from ) {
        Debug.Log("Msg_Welcome  ");

        MyId = msg.YourId;
        //foreach(Msg_Welcome.PeerDat p in msg.Peers) {
        //    Peers.Add(p.Id, new Peer(p.Name, p.Team));
       // }
        SceneManager.LoadScene("one");
    }
    void recv( Msg_NewPeer msg, NetworkConnection from ) {
        Debug.Log("Msg_NewPeer  "+msg.Name);

        Peers.Add(msg.PeerId, new Peer(msg.Name, msg.Team));
        // SceneManager.LoadScene("one");
    }
    void recv( Msg_SpawnObj msg, NetworkConnection from ) {
        Debug.Log("Msg_SpawnObj  ");
        GameObject go = Instantiate(Sys.get().CommanderFab);
        var no = go.AddComponent<NetObj>();
        no.Owner = msg.Owner;

        if(no.Owner == MyId) {
            go.layer = LayerMask.NameToLayer("Selectable");

            foreach(MeshRenderer mr in go.GetComponentsInChildren<MeshRenderer>())
                mr.material.color = Color.blue;
        } else {

        }
        NetObjs.Add(no.Id= msg.ObjId, no);
        // SceneManager.LoadScene("one");
    }

    new void OnEnable() {
        base.OnEnable();
        Debug.Log(" NetClient :: OnEnabled ");


        System.Action<short, NetworkMessageDelegate> reg = Client.RegisterHandler;


        Client.RegisterHandler(MsgType.Connect, onConnect);
        Client.RegisterHandler(MsgType.Disconnect, onDisconnect);
        Client.RegisterHandler(MsgType.Error, OnError);

        reg_Sub<Msg_Ping>(recv);
        reg_Sub<Msg_NewPeer>(recv);
        reg_Sub<Msg_SpawnObj>(recv);
        reg_Sub<Msg_Welcome>(recv);
        reg_Sub<Msg_Generic>(recv);


        Client.Connect(IP, Port);





     //   reg_Sub<Msg_SetUnitDest>(reg, recv);
      //  reg_Sub<Msg_DragCB>(reg, recv);
      //  reg_Sub<Msg_SetReady>(reg, recv);
      //  reg_Sub<Msg_UnitList>(reg, recv);
       // reg_Sub<Msg_Proc>(reg, recv);
    }


    new void Start() {
        base.Start();

    }
    
    void OnLevelWasLoaded() {

        Systm = FindObjectOfType<Sys>();
        if(Systm == null) return;
        Debug.Log(" net.OnLevelLoaded");

        Systm.PostStartCB += gameStart;

    }

   
    new void gameStart() {

        //todo this should move to response of reqScene

        GameObject go;
        if((go = GameObject.Find("Plyr"))!= null) Destroy(go);
        if((go = GameObject.Find("Commander"))!= null) Destroy(go);

        //Systm.TeamInteractMask = 2;

       // Systm.readyCB = () => { send(new Msg_SetReady(Systm.Teams, Systm.TeamInteractMask));  };

        base.gameStart();
        Debug.Log("client.gameStart");


        send(new Msg_Generic(Msg_Generic.SubMessage.LoadedAndReady));
        //send(new Msg_ReqScene());
  
    }


  
}
