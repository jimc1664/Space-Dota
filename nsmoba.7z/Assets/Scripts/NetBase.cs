﻿using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Networking.Types;
using UnityEngine.Networking.Match;
using System.Collections.Generic;

public class NetBase : MonoBehaviour {

    //System.Func< 

    protected Sys Systm;

    protected void send<T>(T msg, NetworkConnection to) where T : Msg, IMsg {
        if(!to.Send(msg.getId(), msg)) {
            Debug.LogError("failed to send message..");
        }
    }
    protected void sendUR<T>(T msg, NetworkConnection to) where T : Msg, IMsg {
        if(!to.SendUnreliable(msg.getId(), msg)) {
            Debug.LogError("failed to Send Unreliable message..");
        }
    }
    public interface IMsg {
        short getId();
    }

    public class Msg :  MessageBase { };
    /*
    //bi-directional
    protected class Msg_SetUnitDest : Msg, IMsg {
        public Msg_SetUnitDest() { }
        public Msg_SetUnitDest(Unit u, Cell to) {
            UnitID = u.Id;
            To = to.Id;
        }

        public int UnitID;
        public int To;

        public short getId() { return Id; }
        public const short Id = MsgType.Highest + 1;
    };
    
    protected class Msg_DragCB : Msg, IMsg {
        public Msg_DragCB() { }
        public Msg_DragCB(Unit u, Vector2 to) {
            UnitID = u.Id;
            To = to;
        }

        public int UnitID;
        public Vector2 To;

        public short getId() { return Id; }
        public const short Id = MsgType.Highest + 2;
    };
    protected class Msg_SetReady : Msg, IMsg {
        public Msg_SetReady() { }
        public Msg_SetReady( List<Team> teams, int mask = -1 ) {
            ReadyMask = 0;
            for(int i = teams.Count; i-- > 0; ) {
                if(teams[i].Ready)
                    ReadyMask |= (1 << i);
            }
            ReadyMask &= mask;
        }
        public int ReadyMask;
   
        public short getId() { return Id; }
        public const short Id = MsgType.Highest + 3;
    };*/

        
    protected class Msg_Generic : Msg, IMsg {
        public enum SubMessage {
            //server -->> client
            RejectInvalidName = 0,
            ClientMismatch,
            //client -->> server
            LoadedAndReady,
            Highest,
        }
        public Msg_Generic() { }
        public Msg_Generic( SubMessage sm ) {
            SM = sm;

            Debug.Log("sending " + SM.ToString() +"    "+ sm.ToString());
        }

        public int _SM;
        public SubMessage SM {
            get {
                if( _SM >= (int)SubMessage.Highest ) Debug.LogError("invalid  Msg_Generic");
                return (SubMessage)_SM; 
            }
            set {
                _SM = (int)value;
            }
        }

        public short getId() { return Id; }
        public const short Id = MsgType.Highest + 1;
    };

    protected class Msg_Ping : Msg, IMsg {
        public int A = Random.Range(0, 100);

        public short getId() { return Id; }
        public const short Id = MsgType.Highest + 2;     
    };
    public const short MsgBiDirectionHighestId = Msg_Ping.Id;
    
    //server send - client recv
    protected class Msg_Welcome: Msg, IMsg {

        public Msg_Welcome() { }
        public Msg_Welcome( int id, short t ) { YourId = id; }// YourTeam = t; }

        
        public struct TeamDat {
            public Color Col;
        }
       // public TeamDat[] Teams;
        public struct PeerDat {
            public int Id;
            public string Name;
            public short Team;

            public void init( int id, string n, short t ) {
                Id = id;
                Name = n;
                Team = t;
            }
        }
       // public PeerDat[] Peers;

        public int YourId;
      //  public short YourTeam;

        public string Map;
        //settings...

        public short getId() { return Id; }
        public const short Id = MsgBiDirectionHighestId + 1;
    };
    protected class Msg_NewPeer : Msg, IMsg {

        public Msg_NewPeer() { }
        public Msg_NewPeer( int id, string n, short t ) { Name = n; Team = t; PeerId = id; }

        public int PeerId;
        public string Name;
        public short Team;

        //settings...

        public short getId() { return Id; }
        public const short Id = MsgBiDirectionHighestId + 2;
    };
    protected class Msg_SpawnObj : Msg, IMsg {

        public Msg_SpawnObj() { }
        public Msg_SpawnObj( int id, int owner ) { ObjId = id; Owner = owner; }

        public int ObjId, Owner;
        

        //settings...

        public short getId() { return Id; }
        public const short Id = MsgBiDirectionHighestId + 3;
    };
    
     /*
     * protected class Msg_UnitList : Msg, IMsg {
        public Msg_UnitList() { }
        public Msg_UnitList( ICollection<Unit> ul ) {
            Units = new UnitDat[Count = (uint)ul.Count ];

            int i = 0;
            foreach( Unit u in ul ) Units[i++].set(u);
           
        }

        public uint Count;
        public struct UnitDat {
            public void set(Unit u) {
                
                Id = u.Id;
                CellI = u.CurCell.Id; DCellI = u.DestCell.Id;
                Number = (ushort)u.Number;
                Team = (byte)u.Team;

                Debug.Log(" unit " + u.Id + "  at " + CellI + "  team " + Team + "  num " + u.Number );
            }
            public int Id;
            public int CellI, DCellI;
            public ushort Number;
            public byte Team;
        }
        public UnitDat[] Units;
      
        public short getId() { return Id; }
        public const short Id = MsgBiDirectionHighestId + 1;

    };
    protected class Msg_Proc: Msg, IMsg {
        public bool Start;
        public Msg_Proc() { }
        public Msg_Proc(bool s) { Start = s; }

        public short getId() { return Id; }
        public const short Id = MsgBiDirectionHighestId + 2;
    };*/


    //client send - server recv
    protected class Msg_ReqScene : Msg, IMsg {

        public short getId() { return Id; }
        public const short Id = MsgBiDirectionHighestId + 1;
    };
    
    protected class Msg_Handshake : Msg, IMsg {

        public Msg_Handshake() { }
        public Msg_Handshake( string s) { Name = s; }

        public string Name;
        public long MagicNo = 9932747823749;  // "security"  (lol)
        public short getId() { return Id; }
        public const short Id = MsgBiDirectionHighestId + 2;
    };



    T recvMsg<T>(NetworkMessage msg) where T : Msg, new() {
        T m = msg.ReadMessage<T>();
        Debug.Log("NetClient::recvMsg " + typeof(T));
        return m;
    }

    void reg_Sub<T>(System.Action<short, NetworkMessageDelegate> reg, System.Action<T, NetworkConnection> recv) where T : Msg, IMsg, new() { reg((new T()).getId(), (NetworkMessage msg) => { recv(recvMsg<T>(msg), msg.conn); }); }

    protected void recv(Msg_Ping p, NetworkConnection from) {
     //   Debug.Log("Ping ");
    }
    protected void OnEnable() {
        Application.runInBackground = true;

    }

    
    protected void regBasicHandlers( System.Action<short,NetworkMessageDelegate> reg ) {
      //  reg(Msg_Ping.Id, recvMsg<Msg_Ping>);
    }
    protected void Start() {

    }

    protected void gameStart() {


        //FindObjectOfType<Turn_Net>().setup(Systm);
    }

    
    public void OnError( NetworkMessage msg ) {
        Debug.LogError("Error ??  "+ msg.ToString());
    }
/*
    protected Unit unit(int id) { 
        Unit u;
        if(!Units.TryGetValue(id, out u)) {
            Debug.LogError("Invalid Unit id!");
        }
        return u;
    }
   // protected Dictionary<int, Cell> Cells = new Dictionary<int, Cell>();
   // protected Dictionary<int, Unit> Units = new Dictionary<int,Unit>();
*/
    protected NetObj unit( int id ) {
        NetObj u;
        if(!NetObjs.TryGetValue(id, out u)) {
            Debug.LogError("Invalid NetObj id!");
        }
        return u;
    }
    protected Dictionary<int, NetObj> NetObjs = new Dictionary<int, NetObj>();

    /*
    protected struct Timer {
        
        const float Rep = 0.15f;
        float Val;
        public bool proc() {
            if((Val += Time.deltaTime) < Rep) return false;
            Val = 0;
            return true;
        }
    };
    protected Timer DragCB_Timer; */

//    const float DragCB_Rep = 0.2f; float DragCB_Timer;
}
