﻿using UnityEngine;
using System.Collections;

public class NetObj : MonoBehaviour {

    public int Id;
    public int Owner;

    void OnEnable() {

       // Id = gameObject.GetInstanceID();
    }
}
