﻿using UnityEngine;
/*
public class SmoothMover : MonoBehaviour {

    public Unit Unt;
    public Vector2 Target;

    void Awake() {
        Unt = GetComponent<Unit>();
    }

    void Update() {
        Vector2 t = Target,c = Unt.Trnsfrm.position;
        if((t - c).sqrMagnitude < 0.01f) {
            Destroy(this);
            c = t;
        } else {
            c = Vector2.Lerp(c, t, 8.0f * Time.deltaTime);
        }
        Unt.dragTo(c);

    }

}
*/