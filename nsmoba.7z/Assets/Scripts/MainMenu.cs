﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {


    public int Port = 1337;
    public string IP = "127.0.0.1";
    public string Name = "Bob";
    public string Message = "";

    NetClient NC;
    void OnGUI() {

        int marginX = 100, marginY = 50;
        GUILayout.BeginArea(new Rect(marginX, marginY, Screen.width - marginX * 2, Screen.height - marginY * 2));

        
        GUILayout.BeginHorizontal();

        GUILayout.BeginVertical();
        GUILayout.Label("Name: ");
        GUILayout.Label("Port: ");
        GUILayout.Label("IP: ");

        GUILayout.EndVertical();
        GUILayout.BeginVertical();
        Name = GUILayout.TextField(Name);
        Port = int.Parse(GUILayout.TextField(""+Port));
        IP = GUILayout.TextField(IP);
        GUILayout.EndVertical();

        GUILayout.EndHorizontal();


        if(GUILayout.Button("Host") && NC == null) {
            var go = new GameObject();
            go.name = "NetMan";
            var ns = go.AddComponent<NetServer>();
            ns.Port = Port;
            DontDestroyOnLoad(go);
            SceneManager.LoadScene("one");
        }

        if(GUILayout.Button("Join") && NC == null ) {
            Message = "Joining...";
            var go = new GameObject();
            go.name = "NetMan";
            NC = go.AddComponent<NetClient>();
            NC.Port = Port;
            NC.IP = IP;
            NC.Name = Name;
            DontDestroyOnLoad(go);
            
           // SceneManager.LoadScene("one");
        }
        //
        if(Message != "") GUILayout.Label(Message);
        GUILayout.EndArea();

        if(NC != null && NC.checkErr(ref Message))
            Destroy(NC.gameObject);
    }
}
