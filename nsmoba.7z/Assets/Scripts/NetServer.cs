﻿using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Networking.Types;
using UnityEngine.Networking.Match;
using System.Collections.Generic;

public class NetServer : NetBase {

    const float PingRate = 0.3f;
    float PingTimer = 0;

    NetworkServerSimple Srvr = new NetworkServerSimple();
    class Client {
        public NetworkConnection Con;
        public string Name;
        //  public Team Team;
        //public int TeamMask;
    };
    Dictionary<int, Client> Clients = new Dictionary<int, Client>();
    List<NetworkConnection> Connecting = new List<NetworkConnection>();

    bool checkSrc(NetworkConnection c1, string err) {
        Client c2;
        return checkSrc(c1, err, out c2);
    }
    bool checkSrc(NetworkConnection c1, string err, out Client c2) {

        // return Conns.TryGetValue(c1.connectionId, out c2) && c2 == c1;

        if(Clients.TryGetValue(c1.connectionId, out c2) && c2.Con == c1)
            return true;
        else
            Debug.LogError("checkSrc err: " + err);
        return false;
    }

    void sendToAll<T>(T msg) where T : Msg, IMsg {
        foreach(Client c in Clients.Values)
            send(msg, c.Con);
    }
    void sendToAll_Except<T>(T msg, NetworkConnection exe) where T : Msg, IMsg {
        foreach(Client c in Clients.Values)
            if(c.Con != exe)
                send(msg, c.Con);
    }
    void sendURToAll<T>(T msg) where T : Msg, IMsg {
        foreach(Client c in Clients.Values)
            sendUR(msg, c.Con);
    }
    void sendURToAll_Except<T>(T msg, NetworkConnection exe) where T : Msg, IMsg {
        foreach(Client c in Clients.Values)
            if(c.Con != exe)
                sendUR(msg, c.Con);
    }

    T recvMsg<T>(NetworkMessage msg) where T : Msg, new() {
        T m = msg.ReadMessage<T>();
     //   Debug.Log("NetServer::recvMsg " + typeof(T));
        return m;
    }
    void reg_Sub<T>(  System.Action<T, NetworkConnection> recv ) where T : Msg, IMsg, new()  { Srvr.RegisterHandler(  (new T()).getId(), ( NetworkMessage msg ) => { recv(recvMsg<T>(msg), msg.conn); }); }

    void onConnect(NetworkMessage msg) {

        int id = msg.conn.connectionId;
        Debug.Log("someone connecting " + id);

        foreach(var nc in Connecting)
            if(nc.connectionId == id || nc == msg.conn) {
                Debug.LogError("  --connection error " + id);
                return;
            }
        Connecting.Add(msg.conn);

        //msg.conn.Send( )
        // msg.conn.Send( 

    }
    void onDisconnect(NetworkMessage msg) {
        Debug.Log("someone disconnected " + msg.conn.connectionId);

        if(!Connecting.Remove(msg.conn)) {
            if(!Clients.Remove(msg.conn.connectionId)) {
                Debug.LogError("  --disconnect error " + msg.conn.connectionId);
            }


        }

    }

    void recv(Msg_ReqScene msg, NetworkConnection from) {
        Debug.Log("Msg_ReqScene ");


        int id = from.connectionId;
        Debug.Log("someone connected " + id);

        if(!Connecting.Remove(from)) {
            Debug.LogError("  --connection error2 " + id);
            return;
        }

        if(Clients.ContainsKey(id)) { //|| Clients.ContainsValue(from)
            Debug.LogError("  --connection error3 " + id);
            return;
        }

        var c = new Client();
        c.Con = from;
      //  c.TeamMask = 2;
     //   Systm.setReady(0, c.TeamMask);
        // c.Team = Systm.Teams[c.TeamI];
        Clients.Add(from.connectionId, c);

      //  send(new Msg_UnitList(Units.Values), from);
      //  send(new Msg_SetReady(Systm.Teams, -1), from);
    }

/*
    void recv(Msg_SetUnitDest msg, NetworkConnection from) {
        Client cln;
        if(!checkSrc(from, "Msg_SetUnitDest", out cln)) return;
        Unit u = unit(msg.UnitID); if(u == null) return;
        Cell c = cell(msg.To); if(c == null) return;

        Debug.Log("recv  Msg_SetUnitDest req from " + from.connectionId);

        //Client cln = Clients[from.connectionId];
        //  Systm.setMyDestCell_Check(u, c, cln.TeamI );

        if(!Systm.interactable(u, cln.TeamMask) || !u.CurCell.isNeighbour(c)) {
            c = u.DestCell;
            msg.To = c.Id;
            //return;
        }

        //  sendToAll(new Msg_SetUnitDest(u, c));
        sendToAll(msg);
        setMyDestCell_Final(u, c);
    }


    void recv(Msg_DragCB msg, NetworkConnection from) {
        if(!checkSrc(from, "Msg_DragCB")) return;
        Unit u = unit(msg.UnitID); if(u == null) return;

        sendURToAll_Except(msg, from);
        dragCB_Final(u, msg.To);
    }
 * 
    void recv(Msg_SetReady msg, NetworkConnection from) {
        Client cln;
        if(!checkSrc(from, "Msg_SetReady", out cln)) return;

        if(Systm.Processing) {
            send(new Msg_SetReady(Systm.Teams, -1), from);
        } else {
            Systm.setReady(msg.ReadyMask, cln.TeamMask);
            sendToAll(new Msg_SetReady(Systm.Teams, -1));
            procCheck();
        }
    }*/


    void recv( Msg_Generic msg, NetworkConnection from ) {
        Debug.Log("Msg_Generic  " + msg.SM.ToString());
        switch(msg.SM) {
            case Msg_Generic.SubMessage.LoadedAndReady:

                GameObject go = Instantiate(Sys.get().CommanderFab);
                var no = go.AddComponent<NetObj>();
                no.Owner = from.connectionId;
                NetObjs.Add(no.Id=go.GetInstanceID(), no);

                sendToAll(new Msg_SpawnObj(no.Id,from.connectionId));
                return;
        }
        Debug.LogError("unhandled  "+ msg._SM );
    }
    void recv( Msg_Handshake msg, NetworkConnection from ) {
        Debug.Log("Msg_Handshake ");


        int id = from.connectionId;
        Debug.Log("..someone connecting  (?) " + id +" nm "+msg.Name );

        if(!Connecting.Contains(from) ||  Clients.ContainsKey(id) ) {
            Debug.LogError("  --connection error... " + id);
            from.Disconnect();
            return;
        }

        if(msg.MagicNo != new Msg_Handshake().MagicNo) {
            Debug.Log(" - reject "+msg.Name +"  client mismatch");
            send(new Msg_Generic(Msg_Generic.SubMessage.ClientMismatch), from);
            from.Disconnect();
            return;            
        }
        if(msg.Name.Length < 3 || msg.Name.Length > 20) {
            Debug.Log(" - reject  "+msg.Name +" invalid name");
            send(new Msg_Generic(Msg_Generic.SubMessage.RejectInvalidName), from);
            return;
        }

        foreach( Client cc in Clients.Values )
            if(cc.Name == msg.Name) {
                Debug.Log(" - reject new "+cc.Name +" already have one" );
                send(new Msg_Generic(Msg_Generic.SubMessage.RejectInvalidName), from );
                return;
            }
        Debug.Log("handshake1 success " + id +" nm "+msg.Name );
     

        var c = new Client();
        c.Con = from;
        c.Name = msg.Name;
       // c.TeamMask = 2;
        //   Systm.setReady(0, c.TeamMask);
        // c.Team = Systm.Teams[c.TeamI];

        var mw = new Msg_Welcome( from.connectionId, 1 );
        if( Clients.Count > 0) {
          //  mw.Peers = new Msg_Welcome.PeerDat[Clients.Count];
            int i = 0;
            foreach( var cc in Clients) {
            //    mw.Peers[i++].init(cc.Key, cc.Value.Name, 0);
            }
        }
        Clients.Add(from.connectionId, c);
            
        send( msg, c.Con);
        sendToAll_Except(new Msg_NewPeer(from.connectionId,c.Name, 1), c.Con);

        //  send(new Msg_UnitList(Units.Values), from);
        //  send(new Msg_SetReady(Systm.Teams, -1), from);
    }
    new void OnEnable() {
        base.OnEnable();
        // regBasicHandlers();

        
       // System.Action<short, NetworkMessageDelegate> reg = Srvr.RegisterHandler;

        // reg(Msg_Ping.Id, recvMsg<Msg_Ping>);

        reg_Sub<Msg_Ping>( recv);
       // reg_Sub<Msg_SetUnitDest>(reg, recv);
     //   reg_Sub<Msg_DragCB>(reg, recv);
       // reg_Sub<Msg_SetReady>(reg, recv);
        reg_Sub<Msg_ReqScene>( recv);
        reg_Sub<Msg_Handshake>(recv);
        reg_Sub<Msg_Generic>(recv);
        //NetworkServer.RegisterHandler(Msg_Ping.Id, ping);

        Srvr.RegisterHandler(MsgType.Connect, onConnect);
        //  NetworkServer.RegisterHandler(MsgType.Ready, onReady);
        Srvr.RegisterHandler(MsgType.Disconnect, onDisconnect);
        Srvr.RegisterHandler(MsgType.Error, OnError);
    }

    new void Start() {
        base.Start();
    }
    public int Port;

    void OnLevelWasLoaded() {
        Systm = FindObjectOfType<Sys>();
        if(Systm == null) return;
        Debug.Log(" net.OnLevelLoaded");
        Systm.PostStartCB += gameStart;
        
        bool listen = Srvr.Listen(Port);

        Debug.Log("listening  " + listen);
    }

    new void gameStart() {

        GameObject go;
        if((go = GameObject.Find("Plyr"))!= null) Destroy(go);
        if((go = GameObject.Find("Commander"))!= null) Destroy(go);

        // Systm.setMyDestCell = setMyDestCellCB;
        // Systm.dragCB = dragCB;
        //Systm.TeamInteractMask = 1;
        /*
        Systm.setMyDestCell = (Unit u, Cell c) => {
            var dc = u.DestCell;
            if(!Systm.setMyDestCell_Raw(u, c)) return false;
            if( dc != c)
                Systm.setReady(0, -1);
            sendToAll(new Msg_SetUnitDest(u, c));
            return true;
        };
        Systm.dragCB = (Unit u, Vector2 at) => {
            if(DragCB_Timer.proc()) {
                sendURToAll(new Msg_DragCB(u, at));
                if(Systm.unready(u.Team)) sendToAll(new Msg_SetReady(Systm.Teams, -1)); 
            }
        };
        SystreadyCB = () => { sendToAll(new Msg_SetReady(Systm.Teams, -1)); procCheck();  };
       Systm.updateCB = () => {

            //i hate c#
            List<int> toRem = new List<int>( Units.Count );
            foreach(var kv in Units) if(kv.Value == null || kv.Value.gameObject == null || kv.Value.Number <= 0  ) toRem.Add(kv.Key);
            foreach(int i in toRem) Units.Remove(i);
           
            sendToAll(new Msg_UnitList(Units.Values));

            if(!Systm.Processing) { //done

                sendToAll(new Msg_Proc(false));
                Systm.setReady(0, -1);
            }
        };
        */

        base.gameStart();
        Debug.Log("srvr.gameStart");

        /*
        var units = FindObjectsOfType<Unit>();
        foreach(var u in units)
            Units.Add(u.Id = u.GetInstanceID(), u);
        */

    }


    /*bool setMyDestCellCB(Unit u, Cell c) {
        if(!Systm.setMyDestCell_Raw(u, c)) return false;
        sendToAll(new Msg_SetUnitDest(u, c));
        return true;
    } 
    void dragCB(Unit u, Vector2 at) {
        if(DragCB_Timer.proc())
            sendURToAll(new Msg_DragCB(u, at));
    }

     */

    void Update() {
        Srvr.Update();
        if((PingTimer += Time.deltaTime) > PingRate) {
            PingTimer = 0;
            sendURToAll(new Msg_Ping());
            /*            Debug.Log("NetworkServer.connections  " + NetworkServer.connections.Count + "   NetworkServer.localConnections  " + NetworkServer.localConnections.Count);
                        foreach(var c in NetworkServer.connections)
                            if( c != null )
                                Debug.Log("c "+c.address + "   " + c.connectionId + "   " + c.hostId + "   " + c.isReady);
                        foreach(var c in NetworkServer.localConnections)
                            if(c != null)
                                Debug.Log("lc " + c.address + "   " + c.connectionId + "   " + c.hostId + "   " + c.isReady);
                        NetworkServer.connections  2   NetworkServer.localConnections  0
            UnityEngine.Debug:Log(Object)
            NetServer:Update() (at Assets/Scripts/NetServer.cs:25)

                        c ::ffff:52.28.68.38   1   0   False
            UnityEngine.Debug:Log(Object)
            NetServer:Update() (at Assets/Scripts/NetServer.cs:28) */

        }
    }


}